#include <stdio.h>

// Function prototype
void printNaturalNumbers(int n);
// Recursive function to print the first n natural numbers
void printNaturalNumbers(int n)
{
    if (n <= 50) // Base case: Stop recursion when n exceeds 50
    {
        printf("%d ", n); // Print the current number
        printNaturalNumbers(n + 1); // Recursive call with next number
    }
}
int main()
{
    int n = 1; // Starting number

    printf("The first 50 natural numbers are:\n");
    printNaturalNumbers(n); // Calling the recursive function

    return 0;
}
